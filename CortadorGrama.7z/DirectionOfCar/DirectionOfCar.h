#ifndef DirectionOfCar_h
#define DirectionOfCar_h

#include "Arduino.h"
#include "CarroController.h"

	
    void changeDirection(CarroController carro, char c, int velocity, char directionCar);
    String readSerial();


#endif
